# PharmaBot — Phase 1 + Phase 2 : Code Source + Campagne de Tests

**Équipe PharmaBot | Ibn Tofaïl University | 2025-2026**
**Prof. Khaoula Boukir — Systèmes Embarqués Temps Réel**

---

## Résultat des tests : 10/10 PASS ✅ — PRÊT PHASE 3 ET PHASE 4

---

## Structure

```
PharmaBot_Final/
├── README.md
├── hospital_robot_spawner/          ← Package ROS2 Phase 1+2
│   ├── setup.py
│   ├── launch/pharmabot_full.launch.py
│   └── hospital_robot_spawner/
│       ├── rt_scheduler.py          EDF Scheduler
│       ├── mission_manager.py       Machine à états + RMS  ← BUG S06 CORRIGÉ
│       ├── navigation_bridge.py     Pont EDF ↔ Robot
│       ├── delivery_detector.py     Détection livraison
│       ├── doctor_request_node.py   Générateur requêtes
│       ├── pharmacist_node.py       Validation pharmacien
│       ├── dma_tasks.py             DMA pipeline
│       ├── watchdog_node.py         Watchdog sécurité
│       ├── dashboard.py             Tableau de bord
│       ├── trained_agent.py         Agent RL
│       └── ...
└── tests/
    └── run_tests_phase1_phase2.py   ← TESTS (autonome, sans ROS2)
```

---

## Exécuter les tests

```bash
# Tous les scénarios
python3 tests/run_tests_phase1_phase2.py

# Verbose (détails de chaque check)
python3 tests/run_tests_phase1_phase2.py -v

# Un seul scénario
python3 tests/run_tests_phase1_phase2.py S03
```

**Aucune dépendance externe — Python 3.8+ stdlib uniquement.**

---

## Scénarios de test

| ID  | Scénario | Type RT | Résultat |
|-----|----------|---------|----------|
| S01 | Mission simple Consultation | FIRM_RT | ✅ PASS |
| S02 | 3 SOFT_RT décalées — tri EDF | SOFT_RT | ✅ PASS |
| S03 | HARD_RT pendant FIRM_RT — Override | HARD_RT | ✅ PASS |
| S04 | Deadline HARD_RT dépassée | HARD_RT | ✅ PASS |
| S05 | Perte de communication | — | ✅ PASS |
| S06 | Absence confirmation livraison | SOFT_RT | ✅ PASS |
| S07 | Panne robot pendant navigation | — | ✅ PASS |
| S08 | Reprise automatique après override | HARD_RT | ✅ PASS |
| S09 | Surcharge 25 requêtes simultanées | Mix | ✅ PASS |
| S10 | Journée hospitalière complète | Mix | ✅ PASS |

---

## Correctif appliqué (Bug S06)

**`mission_manager.py` — `_cb_livraison_confirmee`**

Ajout de 3 gardes avant de terminer une mission :
1. La mission courante doit exister
2. Le département livré doit correspondre à la mission active
3. L'état machine doit être compatible (NAVIGATION/LIVRAISON/URGENCE_OVERRIDE)

---

## Lancer avec ROS2 (environnement Gazebo complet)

```bash
source /opt/ros/humble/setup.bash
cd hospital_robot_spawner
pip install -e .
ros2 launch launch/pharmabot_full.launch.py
```

---

## Topics ROS2 principaux

| Topic | Direction | Description |
|-------|-----------|-------------|
| `/pharmabot/requete` | doctor → scheduler | Requête médicament |
| `/pharmabot/tache_courante` | scheduler → bridge | Mission EDF active |
| `/pharmabot/navigation_goal` | bridge → detector | Coordonnées cible |
| `/pharmabot/nav_status` | bridge → DMA | Arrivée destination |
| `/pharmabot/livraison_confirmee` | detector → scheduler | Fin de mission |
| `/pharmabot/edf_interruption` | scheduler → MM | Override HARD_RT |
| `/pharmabot/etat_robot` | MM → tous | État machine |
| `/pharmabot/dma_pipeline` | DMA → MM | Étapes pipeline |
| `/pharmabot/watchdog` | watchdog → tous | Récupération/Reprise |
| `/pharmabot/pharmacist_ok` | pharmacist → DMA | Validation chargement |
