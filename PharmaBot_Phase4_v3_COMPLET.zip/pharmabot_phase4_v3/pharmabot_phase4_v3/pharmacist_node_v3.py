#!/usr/bin/env python3
"""
Phase 4 v3 — pharmacist_node_v3.py
Pharmacien humain avec workflow visuel Gazebo complet:
  Request Received → Locate Shelf → Pick Medicine → Move to Loading Desk → Place on Tray → Delivery Ready
Anime les bras du modèle SDF pharmacien via joint positions
"""
import rclpy
from rclpy.node import Node
from rclpy.callback_groups import ReentrantCallbackGroup
from std_msgs.msg import String, Bool, Float64MultiArray
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from builtin_interfaces.msg import Duration
import json, time, math
from enum import Enum

class PharmacistState(Enum):
    IDLE          = "IDLE"
    RECEIVING     = "RECEIVING"
    LOCATING      = "LOCATING_SHELF"
    PICKING       = "PICKING_MEDICINE"
    MOVING_DESK   = "MOVING_TO_DESK"
    PLACING_TRAY  = "PLACING_ON_TRAY"
    READY         = "DELIVERY_READY"

SHELF_POSITIONS = {
    "A1": {"x":  0.0, "y": 17.8, "content": "Paracetamol"},
    "B2": {"x":  1.0, "y": 17.8, "content": "Antibiotics"},
    "C1": {"x":  2.0, "y": 17.8, "content": "Insulin"},
    "D3": {"x": -1.0, "y": 17.8, "content": "EmergencyKits"},
    "E1": {"x": -2.0, "y": 17.8, "content": "Syringes"},
    "F2": {"x":  3.0, "y": 17.8, "content": "ICU_Medication"},
}

MEDICATION_TO_SHELF = {
    "Paracetamol":   "A1", "Antibiotics": "B2", "Insulin":       "C1",
    "EmergencyKits": "D3", "Syringes":    "E1", "ICU_Medication": "F2",
}

ARM_POSES = {
    "IDLE":        [0.0,  0.0,  0.0,  0.0,  0.0],
    "REACHING":    [0.8, -0.6, -0.4,  0.4,  0.2],
    "PICKING":     [1.2, -1.0, -0.8,  0.8,  0.1],
    "HOLDING":     [0.6, -0.5, -0.3,  0.3,  0.0],
    "MOVING":      [0.3, -0.3, -0.2,  0.2,  0.0],
    "PLACING":     [0.9, -0.7, -0.5,  0.5, -0.1],
}

class PharmacistNodeV3(Node):
    def __init__(self):
        super().__init__('pharmacist_node_v3')
        self.cb = ReentrantCallbackGroup()

        self.state = PharmacistState.IDLE
        self.current_request = None
        self.target_shelf    = None
        self.med_content     = None
        self.state_start     = time.time()
        self.validation_delay = 4.0

        # Subscribers
        self.create_subscription(String, '/pharmabot/requete_medicale',
            self._request_cb, 10, callback_group=self.cb)
        self.create_subscription(String, '/pharmabot/autorisation_medicament',
            self._auth_cb, 10, callback_group=self.cb)
        self.create_subscription(String, '/pharmabot/navigation_status',
            self._nav_cb, 10, callback_group=self.cb)

        # Publishers
        self.pub_ready     = self.create_publisher(Bool,   '/pharmabot/pharmacist_ready', 10)
        self.pub_auth      = self.create_publisher(String, '/pharmabot/autorisation_medicament', 10)
        self.pub_status    = self.create_publisher(String, '/pharmabot/pharmacist_status', 10)
        self.pub_arm_joints= self.create_publisher(JointTrajectory,
            '/pharmacist_joint_controller/joint_trajectory', 10)
        self.pub_arm_cmd   = self.create_publisher(String, '/pharmabot/arm_cmd', 10)
        self.pub_table_load= self.create_publisher(Bool,   '/pharmabot/table_loaded', 10)

        self.create_timer(0.5, self._workflow_loop, callback_group=self.cb)
        self.create_timer(0.5, self._pub_status_loop, callback_group=self.cb)
        self.get_logger().info("PharmacistNodeV3 démarré | Workflow visuel activé")

    def _request_cb(self, msg):
        try:
            req = json.loads(msg.data)
            if self.state == PharmacistState.IDLE:
                self.get_logger().info(f"Requête reçue: {req}")
                self.current_request = req
                self.state = PharmacistState.RECEIVING
                self.state_start = time.time()
        except Exception as e:
            self.get_logger().error(f"request_cb: {e}")

    def _auth_cb(self, msg):
        try:
            data = json.loads(msg.data)
            if data.get('status') == 'APPROVED' and self.state == PharmacistState.IDLE:
                self.state = PharmacistState.LOCATING
                self.state_start = time.time()
        except Exception:
            pass

    def _nav_cb(self, msg):
        try:
            nav = json.loads(msg.data)
            if nav.get('step') == 'WAITING_PHARMACIST' and self.state == PharmacistState.IDLE:
                self.get_logger().info("Robot en attente — début workflow pharmacien")
                if self.current_request:
                    self.state = PharmacistState.LOCATING
                    self.state_start = time.time()
        except Exception:
            pass

    def _workflow_loop(self):
        elapsed = time.time() - self.state_start

        if self.state == PharmacistState.RECEIVING:
            if elapsed > 2.0:
                med = (self.current_request or {}).get('medicament', 'Paracetamol')
                self.target_shelf = MEDICATION_TO_SHELF.get(med, 'A1')
                self.med_content  = SHELF_POSITIONS[self.target_shelf]['content']
                self.get_logger().info(f"Localisation étagère {self.target_shelf} ({self.med_content})")
                self.state = PharmacistState.LOCATING
                self.state_start = time.time()
                self._set_arm_pose("REACHING")

        elif self.state == PharmacistState.LOCATING:
            if elapsed > 2.5:
                self.get_logger().info(f"Picking {self.med_content} depuis {self.target_shelf}")
                self.state = PharmacistState.PICKING
                self.state_start = time.time()
                self._set_arm_pose("PICKING")

        elif self.state == PharmacistState.PICKING:
            if elapsed > 3.0:
                self.get_logger().info("Médicament saisi → Moving to desk")
                self.state = PharmacistState.MOVING_DESK
                self.state_start = time.time()
                self._set_arm_pose("HOLDING")

        elif self.state == PharmacistState.MOVING_DESK:
            if elapsed > 2.0:
                self.get_logger().info("Arrivé au desk → Placement sur tray robot")
                self.state = PharmacistState.PLACING_TRAY
                self.state_start = time.time()
                self._set_arm_pose("PLACING")

        elif self.state == PharmacistState.PLACING_TRAY:
            if elapsed > 2.5:
                self.get_logger().info("Médicament placé sur tray → DELIVERY READY")
                self.state = PharmacistState.READY
                self.state_start = time.time()
                self._set_arm_pose("IDLE")
                # Notifier robot
                self.pub_ready.publish(Bool(data=True))
                self.pub_table_load.publish(Bool(data=True))
                # Autorisation
                auth = String()
                auth.data = json.dumps({
                    "status": "APPROVED",
                    "medicament": self.med_content,
                    "shelf": self.target_shelf,
                    "timestamp": time.time(),
                })
                self.pub_auth.publish(auth)
                self.get_logger().info("✓ Tray chargé — robot peut partir")

        elif self.state == PharmacistState.READY:
            if elapsed > 5.0:
                self.get_logger().info("Pharmacien retour IDLE")
                self.state = PharmacistState.IDLE
                self.current_request = None
                self.pub_ready.publish(Bool(data=False))

    def _set_arm_pose(self, pose_name: str):
        joints = ARM_POSES.get(pose_name, [0.0]*5)
        traj = JointTrajectory()
        traj.header.stamp = self.get_clock().now().to_msg()
        traj.joint_names = [
            'joint_arm_left', 'joint_elbow_left',
            'joint_arm_right', 'joint_elbow_right', 'joint_head'
        ]
        pt = JointTrajectoryPoint()
        pt.positions = [float(j) for j in joints]
        pt.velocities = [0.0]*5
        pt.time_from_start = Duration(sec=1, nanosec=0)
        traj.points = [pt]
        self.pub_arm_joints.publish(traj)

    def _pub_status_loop(self):
        status = {
            "state":         self.state.value,
            "target_shelf":  self.target_shelf,
            "med_content":   self.med_content,
            "elapsed_step":  round(time.time()-self.state_start, 1),
            "request":       self.current_request,
            "timestamp":     time.time(),
        }
        msg = String(); msg.data = json.dumps(status)
        self.pub_status.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = PharmacistNodeV3()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
