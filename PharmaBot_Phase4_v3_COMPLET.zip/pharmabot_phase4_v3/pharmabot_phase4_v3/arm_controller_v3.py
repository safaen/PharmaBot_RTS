#!/usr/bin/env python3
"""
Phase 4 v3 — arm_controller_v3.py
Contrôleur bras + indicateurs visuels robot :
  - Séquences PICK/PLACE/HOME/NAVIGATE
  - Gyrophare urgence HARD_RT (clignotant via marker rouge)
  - Écran statut LED (publie couleur selon état)
  - Indicateur batterie simulé
  - Synchronisé avec EDF mission state
"""
import rclpy
from rclpy.node import Node
from rclpy.callback_groups import ReentrantCallbackGroup
from std_msgs.msg import String, Bool, ColorRGBA
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from visualization_msgs.msg import Marker, MarkerArray
from builtin_interfaces.msg import Duration
import json, time, math
from enum import Enum

ARM_POSITIONS = {
    "HOME":          [0.0,  0.0,  0.0,  0.0],
    "PICK_READY":    [0.8, -0.8, -0.5,  0.5],
    "PICK_DOWN":     [1.2, -1.2, -0.8,  0.8],
    "LIFT":          [0.6, -0.6, -0.4,  0.4],
    "PLACE_TABLE":   [0.2, -0.2, -0.1,  0.1],
    "NAVIGATE":      [0.3, -0.3, -0.2,  0.2],
    "PLACE_DELIVER": [1.0, -1.0, -0.7,  0.7],
}

PICK_SEQ    = ["HOME","PICK_READY","PICK_DOWN","LIFT","PLACE_TABLE","NAVIGATE"]
DELIVER_SEQ = ["NAVIGATE","PLACE_DELIVER","HOME"]

# Couleurs écran statut
SCREEN_COLORS = {
    "WAITING":    (0.1, 0.1, 0.1),
    "CHARGEMENT": (0.0, 0.8, 1.0),
    "NAVIGATION": (0.1, 0.8, 0.1),
    "LIVRAISON":  (1.0, 0.5, 0.0),
    "RETOUR":     (0.5, 0.1, 0.9),
    "HARD_RT":    (1.0, 0.0, 0.0),
    "ARRIVED":    (0.1, 0.9, 0.1),
}

class ArmState(Enum):
    IDLE = "IDLE"; EXECUTING = "EXECUTING"
    PICKING = "PICKING"; NAVIGATING = "NAVIGATING"; PLACING = "PLACING"

class ArmControllerV3Node(Node):
    def __init__(self):
        super().__init__('arm_controller_v3')
        self.cb = ReentrantCallbackGroup()

        self.arm_state       = ArmState.IDLE
        self.mission_state   = "WAITING"
        self.current_pos     = [0.0, 0.0, 0.0, 0.0]
        self.table_loaded    = False
        self.is_hard_rt      = False
        self.hard_rt_time    = 0.0
        self.battery_level   = 0.85
        self.sequence        = []
        self.seq_idx         = 0
        self.on_complete_cb  = None
        self.mission_count   = 0
        self._flash_state    = False

        # Subscribers
        self.create_subscription(String, '/pharmabot/mission_state',
            self._mission_cb, 10, callback_group=self.cb)
        self.create_subscription(String, '/pharmabot/arm_cmd',
            self._cmd_cb, 10, callback_group=self.cb)
        self.create_subscription(String, '/pharmabot/tache_courante',
            self._task_cb, 10, callback_group=self.cb)

        # Publishers
        self.pub_joints    = self.create_publisher(JointTrajectory,
            '/joint_trajectory_controller/joint_trajectory', 10)
        self.pub_arm_status= self.create_publisher(String, '/pharmabot/arm_status', 10)
        self.pub_table     = self.create_publisher(Bool,   '/pharmabot/table_loaded', 10)
        self.pub_arm_event = self.create_publisher(String, '/pharmabot/arm_event', 10)
        self.pub_markers   = self.create_publisher(MarkerArray, '/pharmabot/robot_indicators', 10)
        self.pub_screen    = self.create_publisher(String, '/pharmabot/status_screen', 10)
        self.pub_battery   = self.create_publisher(String, '/pharmabot/battery_status', 10)

        self.create_timer(0.5, self._pub_status)
        self.create_timer(0.2, self._pub_indicators)
        self.create_timer(5.0, self._drain_battery)

        self._go_to("HOME")
        self.get_logger().info("ArmControllerV3 démarré | Gyrophare + Écran + Batterie actifs")

    # ─── Callbacks ───────────────────────────────────────────────────────
    def _mission_cb(self, msg):
        try:
            data = json.loads(msg.data)
            new_state = data.get('state', '')
            if new_state == self.mission_state: return
            prev = self.mission_state
            self.mission_state = new_state
            self.get_logger().info(f"Arm mission: {prev} → {new_state}")

            if new_state == "CHARGEMENT":
                self.mission_count += 1
                self._run_sequence(PICK_SEQ, on_complete=self._on_pick_done)
            elif new_state == "NAVIGATION":
                self._go_to("NAVIGATE")
            elif new_state == "LIVRAISON":
                self._run_sequence(DELIVER_SEQ, on_complete=self._on_deliver_done)
            elif new_state in ["RETOUR", "WAITING"]:
                if self.table_loaded: self._run_sequence(DELIVER_SEQ)
                else: self._go_to("HOME")
        except Exception as e:
            self.get_logger().error(f"mission_cb: {e}")

    def _cmd_cb(self, msg):
        cmd = msg.data.strip().upper()
        if cmd == "PICK":    self._run_sequence(PICK_SEQ, on_complete=self._on_pick_done)
        elif cmd == "PLACE": self._run_sequence(DELIVER_SEQ, on_complete=self._on_deliver_done)
        elif cmd == "HOME":  self._go_to("HOME")
        elif cmd in ARM_POSITIONS: self._go_to(cmd)

    def _task_cb(self, msg):
        try:
            task = json.loads(msg.data)
            if task.get('priorite') == 'HARD_RT':
                self.is_hard_rt   = True
                self.hard_rt_time = time.time()
            else:
                self.is_hard_rt = False
        except Exception:
            pass

    # ─── Séquences ───────────────────────────────────────────────────────
    def _run_sequence(self, seq, on_complete=None):
        if self.arm_state == ArmState.EXECUTING: return
        self.sequence = list(seq); self.seq_idx = 0
        self.arm_state = ArmState.EXECUTING
        self.on_complete_cb = on_complete
        self.get_logger().info(f"Séquence: {' → '.join(seq)}")
        self._next_step()

    def _next_step(self):
        if self.seq_idx >= len(self.sequence):
            self.arm_state = ArmState.IDLE
            if self.on_complete_cb:
                self.on_complete_cb()
            return
        step = self.sequence[self.seq_idx]; self.seq_idx += 1
        self.get_logger().info(f"Step [{self.seq_idx}/{len(self.sequence)}]: {step}")
        self._publish_event(step)
        dur = 1.0
        self._send_joints(ARM_POSITIONS[step])
        self.current_pos = list(ARM_POSITIONS[step])
        self.create_timer(dur, lambda: self._next_step())

    def _go_to(self, pos_name):
        if pos_name not in ARM_POSITIONS: return
        self._send_joints(ARM_POSITIONS[pos_name])
        self.current_pos = list(ARM_POSITIONS[pos_name])

    def _send_joints(self, joints):
        traj = JointTrajectory()
        traj.header.stamp = self.get_clock().now().to_msg()
        traj.joint_names = ['j_ua_l','j_ua_r','j_el_l','j_el_r']
        pt = JointTrajectoryPoint()
        pt.positions  = [float(j) for j in joints]
        pt.velocities = [0.0]*4
        pt.time_from_start = Duration(sec=0, nanosec=500000000)
        traj.points = [pt]
        self.pub_joints.publish(traj)

    def _on_pick_done(self):
        self.table_loaded = True
        self.arm_state = ArmState.NAVIGATING
        self.pub_table.publish(Bool(data=True))
        self._publish_event("TABLE_LOADED")
        self.get_logger().info("✓ PICK done — table chargée")

    def _on_deliver_done(self):
        self.table_loaded = False
        self.arm_state = ArmState.IDLE
        self.pub_table.publish(Bool(data=False))
        self._publish_event("DELIVERED")
        self.get_logger().info("✓ DELIVER done — médicament livré")

    def _publish_event(self, etype):
        msg = String()
        msg.data = json.dumps({"type":etype,"state":self.arm_state.value,
                               "mission_state":self.mission_state,"timestamp":time.time()})
        self.pub_arm_event.publish(msg)

    # ─── Indicateurs visuels ─────────────────────────────────────────────
    def _pub_indicators(self):
        arr = MarkerArray()
        now = self.get_clock().now().to_msg()
        self._flash_state = not self._flash_state
        hard_rt_active = self.is_hard_rt and (time.time()-self.hard_rt_time < 10.0)

        # 1. Gyrophare urgence (orange clignotant si HARD_RT, sinon gris)
        gyro = Marker()
        gyro.header.frame_id = 'base_link'; gyro.header.stamp = now
        gyro.ns = 'gyrophare'; gyro.id = 0; gyro.type = Marker.SPHERE
        gyro.action = Marker.ADD
        gyro.pose.position.z = 0.38; gyro.pose.orientation.w = 1.0
        gyro.scale.x = gyro.scale.y = gyro.scale.z = 0.12
        if hard_rt_active and self._flash_state:
            gyro.color.r=1.0; gyro.color.g=0.3; gyro.color.b=0.0; gyro.color.a=1.0
        elif hard_rt_active:
            gyro.color.r=0.9; gyro.color.g=0.1; gyro.color.b=0.0; gyro.color.a=0.6
        else:
            gyro.color.r=0.5; gyro.color.g=0.5; gyro.color.b=0.5; gyro.color.a=0.4
        gyro.lifetime = Duration(sec=0, nanosec=300000000)
        arr.markers.append(gyro)

        # 2. Écran statut (couleur selon mission)
        scr = Marker()
        scr.header.frame_id='base_link'; scr.header.stamp=now
        scr.ns='status_screen'; scr.id=1; scr.type=Marker.CUBE
        scr.action=Marker.ADD
        scr.pose.position.x=0.34; scr.pose.position.z=-0.04
        scr.pose.orientation.w=1.0
        scr.scale.x=0.01; scr.scale.y=0.15; scr.scale.z=0.08
        col_key = "HARD_RT" if hard_rt_active else self.mission_state
        col = SCREEN_COLORS.get(col_key, (0.05, 0.3, 0.05))
        scr.color.r=col[0]; scr.color.g=col[1]; scr.color.b=col[2]; scr.color.a=0.95
        scr.lifetime=Duration(sec=0, nanosec=300000000)
        arr.markers.append(scr)

        # 3. Indicateur batterie (barre verte/orange/rouge)
        bat_level = max(0.0, min(1.0, self.battery_level))
        bat = Marker()
        bat.header.frame_id='base_link'; bat.header.stamp=now
        bat.ns='battery'; bat.id=2; bat.type=Marker.CUBE
        bat.action=Marker.ADD
        bat.pose.position.x=0.34; bat.pose.position.y=0.18
        bat.pose.position.z=-0.04 + (bat_level-0.5)*0.05
        bat.pose.orientation.w=1.0
        bat.scale.x=0.01; bat.scale.y=0.032; bat.scale.z=bat_level*0.06
        if bat_level > 0.5:   bat.color.r=0.1;  bat.color.g=0.85; bat.color.b=0.1
        elif bat_level > 0.2: bat.color.r=0.9;  bat.color.g=0.7;  bat.color.b=0.0
        else:                  bat.color.r=0.95; bat.color.g=0.1;  bat.color.b=0.1
        bat.color.a=0.9
        bat.lifetime=Duration(sec=0, nanosec=300000000)
        arr.markers.append(bat)

        # 4. Sphère état mission au-dessus du robot
        sphere = Marker()
        sphere.header.frame_id='base_link'; sphere.header.stamp=now
        sphere.ns='mission_sphere'; sphere.id=3; sphere.type=Marker.SPHERE
        sphere.action=Marker.ADD
        sphere.pose.position.z=0.75; sphere.pose.orientation.w=1.0
        sphere.scale.x=sphere.scale.y=sphere.scale.z=0.18
        if hard_rt_active:
            sphere.color.r=1.0; sphere.color.g=0.0; sphere.color.b=0.0
        else:
            c = SCREEN_COLORS.get(self.mission_state,(0.5,0.5,0.5))
            sphere.color.r=c[0]; sphere.color.g=c[1]; sphere.color.b=c[2]
        sphere.color.a=0.85
        sphere.lifetime=Duration(sec=0, nanosec=300000000)
        arr.markers.append(sphere)

        self.pub_markers.publish(arr)

        # Publier statut écran
        scr_msg = String()
        scr_msg.data = json.dumps({
            "mission_state": self.mission_state,
            "is_hard_rt":    hard_rt_active,
            "color":         list(col),
            "table_loaded":  self.table_loaded,
            "arm_state":     self.arm_state.value,
        })
        self.pub_screen.publish(scr_msg)

    def _drain_battery(self):
        """Simule la décharge batterie pendant navigation."""
        if self.mission_state in ["NAVIGATION","CHARGEMENT","LIVRAISON"]:
            self.battery_level = max(0.05, self.battery_level - 0.002)
        else:
            self.battery_level = min(1.0, self.battery_level + 0.001)

        bat_msg = String()
        bat_msg.data = json.dumps({
            "level": round(self.battery_level, 3),
            "percent": round(self.battery_level*100, 1),
            "charging": self.mission_state == "WAITING",
        })
        self.pub_battery.publish(bat_msg)

    def _pub_status(self):
        msg = String()
        msg.data = json.dumps({
            "arm_state":    self.arm_state.value,
            "mission_state":self.mission_state,
            "joints":       [round(j,3) for j in self.current_pos],
            "table_loaded": self.table_loaded,
            "is_hard_rt":   self.is_hard_rt,
            "battery":      round(self.battery_level,3),
            "mission_count":self.mission_count,
            "timestamp":    time.time(),
        })
        self.pub_arm_status.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = ArmControllerV3Node()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
