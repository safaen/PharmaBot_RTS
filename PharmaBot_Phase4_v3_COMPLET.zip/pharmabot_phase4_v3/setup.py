from setuptools import setup, find_packages
import os
from glob import glob
package_name = 'pharmabot_phase4_v3'
setup(
    name=package_name, version='4.3.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',['resource/'+package_name]),
        ('share/'+package_name,['package.xml']),
        (os.path.join('share',package_name,'launch'),glob('launch/*.launch.py')),
        (os.path.join('share',package_name,'worlds'),glob('worlds/*.world')),
        (os.path.join('share',package_name,'models','pharmabot_v3'),glob('models/pharmabot_v3/*')),
        (os.path.join('share',package_name,'models','pharmacist_human'),glob('models/pharmacist_human/*')),
    ],
    install_requires=['setuptools'], zip_safe=True,
    entry_points={'console_scripts':[
        'pharmacist_node_v3 = pharmabot_phase4_v3.pharmacist_node_v3:main',
        'arm_controller_v3  = pharmabot_phase4_v3.arm_controller_v3:main',
    ]},
)
