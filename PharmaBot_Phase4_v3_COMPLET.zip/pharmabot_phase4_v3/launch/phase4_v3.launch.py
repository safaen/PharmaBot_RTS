"""Phase 4 v3 Launch — Pharmacie complète + pharmacien + robot blanc + zones A-F"""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, TimerAction
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    ua = lambda n,d: DeclareLaunchArgument(n, default_value=d)
    pkg = FindPackageShare('pharmabot_phase4_v3')

    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([PathJoinSubstitution([
            FindPackageShare('gazebo_ros'),'launch','gazebo.launch.py'])]),
        launch_arguments={
            'world': PathJoinSubstitution([pkg,'worlds','pharmacy_zones_v3.world']),
            'verbose': 'false',
        }.items(),
        condition=IfCondition(LaunchConfiguration('use_gazebo')))

    return LaunchDescription([
        ua('use_gazebo','true'), ua('use_sim_time','true'),
        ua('spawn_pharmacist','true'), ua('spawn_robot','true'),

        gazebo_launch,

        # Spawn PharmaBot v3
        TimerAction(period=3.0, actions=[Node(
            package='gazebo_ros', executable='spawn_entity.py',
            name='spawn_robot',
            arguments=['-entity','pharmabot_v3',
                       '-file', PathJoinSubstitution([pkg,'models','pharmabot_v3','model.sdf']),
                       '-x','1.0','-y','13.5','-z','0.12'],
            output='screen',
            condition=IfCondition(LaunchConfiguration('spawn_robot')))]),

        # Spawn Pharmacien
        TimerAction(period=4.0, actions=[Node(
            package='gazebo_ros', executable='spawn_entity.py',
            name='spawn_pharmacist',
            arguments=['-entity','pharmacist_human',
                       '-file', PathJoinSubstitution([pkg,'models','pharmacist_human','model.sdf']),
                       '-x','0.5','-y','9.2','-z','0.0','-R','0','-P','0','-Y','3.14'],
            output='screen',
            condition=IfCondition(LaunchConfiguration('spawn_pharmacist')))]),

        # Pharmacist Node v3
        TimerAction(period=5.0, actions=[Node(
            package='pharmabot_phase4_v3', executable='pharmacist_node_v3',
            name='pharmacist_node_v3',
            parameters=[{'use_sim_time': True}], output='screen')]),

        # Arm Controller v3
        TimerAction(period=5.5, actions=[Node(
            package='pharmabot_phase4_v3', executable='arm_controller_v3',
            name='arm_controller_v3',
            parameters=[{'use_sim_time': True}], output='screen')]),

        # Robot State Publisher
        TimerAction(period=4.5, actions=[Node(
            package='robot_state_publisher', executable='robot_state_publisher',
            name='robot_state_publisher',
            parameters=[{'use_sim_time': True}])]),
    ])
