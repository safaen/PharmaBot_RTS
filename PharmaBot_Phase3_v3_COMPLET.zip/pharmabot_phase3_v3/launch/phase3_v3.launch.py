"""Phase 3 v3 Launch — SLAM Toolbox réel + Navigation multi-étapes + RViz complet"""
import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, TimerAction
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    ua = lambda n,d,desc: DeclareLaunchArgument(n, default_value=d, description=desc)
    pkg = FindPackageShare('pharmabot_phase3_v3')

    return LaunchDescription([
        ua('use_nav2',     'true',  'Activer Nav2'),
        ua('use_slam_toolbox','true','Activer slam_toolbox réel'),
        ua('use_rviz',     'true',  'Lancer RViz'),
        ua('use_gazebo',   'false', 'Lancer Gazebo (false si Phase4 le gère)'),
        ua('use_sim_time', 'true',  'Utiliser sim time'),

        # ── Static TF
        Node(package='tf2_ros', executable='static_transform_publisher',
             name='tf_map_odom',
             arguments=['0','0','0','0','0','0','map','odom'],
             parameters=[{'use_sim_time': True}]),

        # ── SLAM Toolbox (si activé)
        Node(package='slam_toolbox', executable='async_slam_toolbox_node',
             name='slam_toolbox',
             parameters=[
                 PathJoinSubstitution([pkg,'config','slam_toolbox_params.yaml']),
                 {'use_sim_time': LaunchConfiguration('use_sim_time')}
             ],
             condition=IfCondition(LaunchConfiguration('use_slam_toolbox')),
             output='screen'),

        # ── SLAM Manager v3 (Knowledge Base + markers)
        TimerAction(period=2.0, actions=[
            Node(package='pharmabot_phase3_v3',
                 executable='slam_toolbox_manager',
                 name='slam_toolbox_manager',
                 parameters=[{'use_sim_time': True}],
                 output='screen')
        ]),

        # ── Navigation Bridge v3
        TimerAction(period=3.0, actions=[
            Node(package='pharmabot_phase3_v3',
                 executable='navigation_bridge_v3',
                 name='navigation_bridge_v3',
                 parameters=[{'use_sim_time': True}],
                 output='screen')
        ]),

        # ── Trained Agent v3 (multi-étapes)
        TimerAction(period=4.0, actions=[
            Node(package='pharmabot_phase3_v3',
                 executable='trained_agent_v3',
                 name='trained_agent_v3',
                 parameters=[{
                     'use_sim_time': True,
                     'use_nav2': LaunchConfiguration('use_nav2'),
                     'use_slam': LaunchConfiguration('use_slam_toolbox'),
                     'goal_tolerance': 0.5,
                     'pharmacist_wait_timeout': 30.0,
                 }],
                 output='screen')
        ]),

        # ── Nav2
        TimerAction(period=5.0, actions=[
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource([
                    PathJoinSubstitution([
                        FindPackageShare('nav2_bringup'),'launch','navigation_launch.py'])
                ]),
                launch_arguments={
                    'use_sim_time': 'true',
                    'params_file': PathJoinSubstitution([pkg,'config','nav2_params.yaml']),
                }.items(),
                condition=IfCondition(LaunchConfiguration('use_nav2'))
            )
        ]),

        # ── RViz
        TimerAction(period=6.0, actions=[
            Node(package='rviz2', executable='rviz2', name='rviz2',
                 arguments=['-d', PathJoinSubstitution([pkg,'rviz','pharmabot_v3_full.rviz'])],
                 parameters=[{'use_sim_time': True}],
                 condition=IfCondition(LaunchConfiguration('use_rviz')))
        ]),
    ])
