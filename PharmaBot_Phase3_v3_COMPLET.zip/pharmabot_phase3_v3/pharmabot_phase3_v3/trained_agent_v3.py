#!/usr/bin/env python3
"""
Phase 3 v3 — trained_agent_v3.py
Navigation multi-étapes complète :
  Pharmacy → LoadingStation → Wait pharmacist → Target Room → Deliver → Return
Intègre : Knowledge Base étagères, route visualisée, EDF priority display
"""
import rclpy
from rclpy.node import Node
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.action import ActionClient
from std_msgs.msg import String, Bool
from geometry_msgs.msg import PoseStamped, Twist
from nav_msgs.msg import Odometry
from geometry_msgs.msg import PoseWithCovarianceStamped
from sensor_msgs.msg import LaserScan
from nav2_msgs.action import NavigateToPose
import json, math, time
from enum import Enum

KNOWLEDGE_BASE = {
    "Pharmacy":       {"x":  1.0, "y": 16.0, "yaw": 0.0},
    "LoadingStation": {"x":  1.0, "y": 14.5, "yaw": 3.14},
    "ParkingZone":    {"x":  1.0, "y": 13.5, "yaw": 3.14},
    "ICU":            {"x": 11.0, "y":  5.5, "yaw": 0.0},
    "Emergency":      {"x": -5.0, "y": -6.6, "yaw": 1.57},
    "Consult":        {"x": -2.0, "y":-27.0, "yaw": 3.14},
    "Home":           {"x":  0.0, "y":  0.0, "yaw": 0.0},
}

class NavStep(Enum):
    IDLE               = "IDLE"
    GOING_PHARMACY     = "GOING_PHARMACY"
    GOING_PARKING      = "GOING_PARKING"
    GOING_LOADING      = "GOING_LOADING"
    WAITING_PHARMACIST = "WAITING_PHARMACIST"
    GOING_TARGET       = "GOING_TARGET"
    DELIVERING         = "DELIVERING"
    GOING_HOME         = "GOING_HOME"
    RECOVERY           = "RECOVERY"
    ARRIVED            = "ARRIVED"

class TrainedAgentV3Node(Node):
    def __init__(self):
        super().__init__('trained_agent_v3')
        self.cb = ReentrantCallbackGroup()

        self.declare_parameter('use_nav2', True)
        self.declare_parameter('use_slam', True)
        self.declare_parameter('goal_tolerance', 0.5)
        self.declare_parameter('max_linear_vel', 0.5)
        self.declare_parameter('max_angular_vel', 1.0)
        self.declare_parameter('pharmacist_wait_timeout', 30.0)
        self.declare_parameter('recovery_attempts', 3)

        self.use_nav2 = self.get_parameter('use_nav2').value
        self.use_slam = self.get_parameter('use_slam').value
        self.goal_tol = self.get_parameter('goal_tolerance').value
        self.max_lin  = self.get_parameter('max_linear_vel').value
        self.max_ang  = self.get_parameter('max_angular_vel').value
        self.pharm_timeout = self.get_parameter('pharmacist_wait_timeout').value
        self.max_recovery  = self.get_parameter('recovery_attempts').value

        # État
        self.nav_step       = NavStep.IDLE
        self.current_task   = None
        self.target_room    = None
        self.target_shelf   = None
        self.edf_priority   = "SOFT_RT"
        self.edf_deadline   = 0.0
        self.robot_x = self.robot_y = self.robot_yaw = 0.0
        self.pharmacist_ready = False
        self.table_loaded   = False
        self.recovery_count = 0
        self.step_start_time = time.time()
        self.mission_start   = time.time()
        self.route_waypoints = []
        self.nav2_handle    = None

        # Subscribers
        self.create_subscription(String, '/pharmabot/tache_courante',
            self._task_cb, 10, callback_group=self.cb)
        self.create_subscription(Bool, '/pharmabot/pharmacist_ready',
            self._pharm_cb, 10, callback_group=self.cb)
        self.create_subscription(Bool, '/pharmabot/table_loaded',
            self._table_cb, 10, callback_group=self.cb)
        self.create_subscription(PoseWithCovarianceStamped, '/amcl_pose',
            self._amcl_cb, 10, callback_group=self.cb)
        self.create_subscription(Odometry, '/odom',
            self._odom_cb, 10, callback_group=self.cb)
        self.create_subscription(LaserScan, '/scan',
            self._scan_cb, 10, callback_group=self.cb)

        # Publishers
        self.pub_cmd      = self.create_publisher(Twist, '/cmd_vel', 10)
        self.pub_goal     = self.create_publisher(PoseStamped, '/goal_pose', 10)
        self.pub_status   = self.create_publisher(String, '/pharmabot/navigation_status', 10)
        self.pub_reached  = self.create_publisher(Bool, '/pharmabot/goal_reached', 10)
        self.pub_room     = self.create_publisher(String, '/pharmabot/current_room', 10)
        self.pub_metrics  = self.create_publisher(String, '/pharmabot/nav_metrics', 10)
        self.pub_route    = self.create_publisher(String, '/pharmabot/delivery_route_json', 10)
        self.pub_edf_disp = self.create_publisher(String, '/pharmabot/edf_display', 10)
        self.pub_mission_viz = self.create_publisher(String, '/pharmabot/mission_viz', 10)
        self.pub_arm_cmd  = self.create_publisher(String, '/pharmabot/arm_cmd', 10)

        if self.use_nav2:
            self.nav2_client = ActionClient(self, NavigateToPose,
                'navigate_to_pose', callback_group=self.cb)

        self.create_timer(0.1, self._nav_loop, callback_group=self.cb)
        self.create_timer(0.5, self._pub_status, callback_group=self.cb)
        self.create_timer(0.2, self._pub_edf_display, callback_group=self.cb)
        self.get_logger().info("TrainedAgentV3 démarré | Multi-étapes actif")

    # ─── Callbacks ───────────────────────────────────────────────────────
    def _task_cb(self, msg):
        try:
            task = json.loads(msg.data)
            room = task.get('salle', task.get('room', ''))
            prio = task.get('priorite', 'SOFT_RT')
            dead = float(task.get('deadline', 60.0))
            shelf = task.get('shelf', None)
            if room not in KNOWLEDGE_BASE:
                self.get_logger().warn(f"Salle inconnue: {room}")
                return
            if self.nav_step in [NavStep.IDLE, NavStep.ARRIVED] or prio == 'HARD_RT':
                self.get_logger().info(f"Nouvelle mission: {room} | {prio} | deadline={dead}s")
                self.current_task = task
                self.target_room  = room
                self.target_shelf = shelf
                self.edf_priority = prio
                self.edf_deadline = dead
                self.recovery_count = 0
                self.mission_start  = time.time()
                self._build_route(room)
                self._start_mission()
        except Exception as e:
            self.get_logger().error(f"task_cb: {e}")

    def _pharm_cb(self, msg): self.pharmacist_ready = msg.data
    def _table_cb(self, msg): self.table_loaded = msg.data

    def _amcl_cb(self, msg):
        p = msg.pose.pose
        self.robot_x, self.robot_y = p.position.x, p.position.y
        siny = 2*(p.orientation.w*p.orientation.z + p.orientation.x*p.orientation.y)
        cosy = 1 - 2*(p.orientation.y**2 + p.orientation.z**2)
        self.robot_yaw = math.atan2(siny, cosy)

    def _odom_cb(self, msg):
        if not self.use_slam:
            p = msg.pose.pose
            self.robot_x, self.robot_y = p.position.x, p.position.y

    def _scan_cb(self, msg): self._laser = msg

    # ─── Route & Mission ─────────────────────────────────────────────────
    def _build_route(self, target_room):
        """Construit la route complète : Parking→LoadingStation→TargetRoom→Home"""
        kb = KNOWLEDGE_BASE
        self.route_waypoints = [
            ("ParkingZone",    kb["ParkingZone"]["x"],    kb["ParkingZone"]["y"]),
            ("LoadingStation", kb["LoadingStation"]["x"], kb["LoadingStation"]["y"]),
            (target_room,      kb[target_room]["x"],      kb[target_room]["y"]),
            ("Home",           kb["Home"]["x"],           kb["Home"]["y"]),
        ]
        route_msg = String()
        route_msg.data = json.dumps({
            "waypoints": [{"name":w[0],"x":w[1],"y":w[2]} for w in self.route_waypoints],
            "target": target_room, "priority": self.edf_priority,
        })
        self.pub_route.publish(route_msg)
        self.get_logger().info(f"Route: {' → '.join(w[0] for w in self.route_waypoints)}")

    def _start_mission(self):
        self.get_logger().info("Mission start → GOING_PARKING")
        self.nav_step = NavStep.GOING_PARKING
        self.step_start_time = time.time()
        self._send_goal("ParkingZone")

    # ─── Navigation Loop ─────────────────────────────────────────────────
    def _nav_loop(self):
        if self.nav_step == NavStep.IDLE:
            return

        dist = self._dist_to_current_goal()

        if self.nav_step == NavStep.GOING_PARKING:
            if dist < self.goal_tol:
                self.get_logger().info("Parking atteint → GOING_LOADING")
                self.nav_step = NavStep.GOING_LOADING
                self.step_start_time = time.time()
                self._send_goal("LoadingStation")

        elif self.nav_step == NavStep.GOING_LOADING:
            if dist < self.goal_tol:
                self.get_logger().info("LoadingStation atteint → WAITING_PHARMACIST")
                self.nav_step = NavStep.WAITING_PHARMACIST
                self.step_start_time = time.time()
                self.pub_cmd.publish(Twist())

        elif self.nav_step == NavStep.WAITING_PHARMACIST:
            elapsed = time.time() - self.step_start_time
            if self.table_loaded:
                self.get_logger().info("Table chargée → GOING_TARGET")
                self.nav_step = NavStep.GOING_TARGET
                self.step_start_time = time.time()
                self._send_goal(self.target_room)
            elif elapsed > self.pharm_timeout:
                self.get_logger().warn(f"Timeout pharmacist ({self.pharm_timeout}s) → on continue")
                self.nav_step = NavStep.GOING_TARGET
                self._send_goal(self.target_room)

        elif self.nav_step == NavStep.GOING_TARGET:
            if dist < self.goal_tol:
                self.get_logger().info(f"Arrivé à {self.target_room} → DELIVERING")
                self.nav_step = NavStep.DELIVERING
                self.step_start_time = time.time()
                self.pub_cmd.publish(Twist())
                self.pub_reached.publish(Bool(data=True))
                arm = String(); arm.data = "PLACE"; self.pub_arm_cmd.publish(arm)

        elif self.nav_step == NavStep.DELIVERING:
            if time.time() - self.step_start_time > 3.0:
                self.get_logger().info("Livraison effectuée → GOING_HOME")
                self.nav_step = NavStep.GOING_HOME
                self._send_goal("Home")

        elif self.nav_step == NavStep.GOING_HOME:
            if dist < self.goal_tol:
                self.get_logger().info("Retour Home → ARRIVED")
                self.nav_step = NavStep.ARRIVED
                self.pub_cmd.publish(Twist())
                self._pub_final_metrics()

        elif self.nav_step == NavStep.RECOVERY:
            if time.time() - self.step_start_time > 3.0:
                self.recovery_count += 1
                if self.recovery_count > self.max_recovery:
                    self.get_logger().error("Max recovery → abandon")
                    self.nav_step = NavStep.IDLE
                else:
                    self.get_logger().warn(f"Recovery #{self.recovery_count}")
                    self._start_mission()

    def _dist_to_current_goal(self):
        targets = {
            NavStep.GOING_PARKING:  "ParkingZone",
            NavStep.GOING_LOADING:  "LoadingStation",
            NavStep.GOING_TARGET:   self.target_room,
            NavStep.GOING_HOME:     "Home",
        }
        room = targets.get(self.nav_step)
        if not room or room not in KNOWLEDGE_BASE:
            return 999
        gx = KNOWLEDGE_BASE[room]["x"]
        gy = KNOWLEDGE_BASE[room]["y"]
        return math.sqrt((gx-self.robot_x)**2 + (gy-self.robot_y)**2)

    def _send_goal(self, room_name):
        if room_name not in KNOWLEDGE_BASE:
            return
        data = KNOWLEDGE_BASE[room_name]
        ps = PoseStamped()
        ps.header.frame_id = 'map'
        ps.header.stamp = self.get_clock().now().to_msg()
        ps.pose.position.x = float(data['x'])
        ps.pose.position.y = float(data['y'])
        yaw = float(data['yaw'])
        ps.pose.orientation.z = math.sin(yaw/2)
        ps.pose.orientation.w = math.cos(yaw/2)
        self.pub_goal.publish(ps)

        if self.use_nav2 and self.nav2_client.wait_for_server(timeout_sec=1.0):
            goal = NavigateToPose.Goal()
            goal.pose = ps
            fut = self.nav2_client.send_goal_async(goal)
            fut.add_done_callback(self._nav2_resp_cb)

        self.get_logger().info(f"Goal → {room_name} ({data['x']:.1f},{data['y']:.1f})")

    def _nav2_resp_cb(self, future):
        handle = future.result()
        if handle.accepted:
            self.nav2_handle = handle
            res_fut = handle.get_result_async()
            res_fut.add_done_callback(self._nav2_done_cb)

    def _nav2_done_cb(self, future):
        result = future.result()
        if result.status != 4:
            self.get_logger().warn("Nav2 échec → recovery")
            self.nav_step = NavStep.RECOVERY
            self.step_start_time = time.time()
            cmd = Twist(); cmd.linear.x = -0.2
            self.pub_cmd.publish(cmd)

    # ─── Publishers statut + EDF display ─────────────────────────────────
    def _pub_status(self):
        dist = self._dist_to_current_goal()
        msg = String()
        msg.data = json.dumps({
            "step": self.nav_step.value,
            "target_room": self.target_room,
            "priority": self.edf_priority,
            "deadline": self.edf_deadline,
            "deadline_remaining": max(0, self.edf_deadline-(time.time()-self.mission_start)),
            "robot_x": round(self.robot_x,2),
            "robot_y": round(self.robot_y,2),
            "dist_to_goal": round(dist,2),
            "table_loaded": self.table_loaded,
            "pharmacist_ready": self.pharmacist_ready,
            "recovery_count": self.recovery_count,
            "route": [w[0] for w in self.route_waypoints],
            "timestamp": time.time(),
        })
        self.pub_status.publish(msg)

        r = String(); r.data = self.nav_step.value
        self.pub_room.publish(r)

    def _pub_edf_display(self):
        """Publie l'affichage EDF pour RViz overlay et topics."""
        remaining = max(0, self.edf_deadline - (time.time()-self.mission_start))
        urgent = remaining < 10.0 and self.nav_step not in [NavStep.IDLE, NavStep.ARRIVED]
        msg = String()
        msg.data = json.dumps({
            "mission_step":    self.nav_step.value,
            "target":          self.target_room or "—",
            "priority":        self.edf_priority,
            "deadline_remain": round(remaining,1),
            "urgent":          urgent,
            "shelf":           self.target_shelf,
            "table_loaded":    self.table_loaded,
        })
        self.pub_edf_disp.publish(msg)

        viz = String()
        step_labels = {
            NavStep.GOING_PARKING:     "Parking robot...",
            NavStep.GOING_LOADING:     "Vers loading station...",
            NavStep.WAITING_PHARMACIST:"Attente pharmacien...",
            NavStep.GOING_TARGET:      f"Navigation → {self.target_room}",
            NavStep.DELIVERING:        "Livraison en cours...",
            NavStep.GOING_HOME:        "Retour pharmacie...",
            NavStep.ARRIVED:           "Mission accomplie!",
            NavStep.IDLE:              "En attente de mission",
        }
        viz.data = json.dumps({
            "label": step_labels.get(self.nav_step, "..."),
            "priority_color": "#FF0000" if self.edf_priority=="HARD_RT" else "#00AA00",
            "deadline_bar": round(remaining/max(self.edf_deadline,1)*100,0),
        })
        self.pub_mission_viz.publish(viz)

    def _pub_final_metrics(self):
        elapsed = time.time() - self.mission_start
        msg = String()
        msg.data = json.dumps({
            "mission_complete": True,
            "target_room": self.target_room,
            "priority": self.edf_priority,
            "elapsed_s": round(elapsed,2),
            "deadline_met": elapsed < self.edf_deadline,
            "recovery_count": self.recovery_count,
            "timestamp": time.time(),
        })
        self.pub_metrics.publish(msg)
        self.get_logger().info(
            f"Mission terminée: {self.target_room} | {elapsed:.1f}s | "
            f"deadline={'OK' if elapsed<self.edf_deadline else 'LATE'}")


def main(args=None):
    rclpy.init(args=args)
    node = TrainedAgentV3Node()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
