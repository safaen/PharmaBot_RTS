from setuptools import setup, find_packages
import os
from glob import glob
package_name = 'pharmabot_phase3_v3'
setup(
    name=package_name, version='3.3.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',['resource/'+package_name]),
        ('share/'+package_name,['package.xml']),
        (os.path.join('share',package_name,'launch'),glob('launch/*.launch.py')),
        (os.path.join('share',package_name,'config'),glob('config/*.yaml')),
        (os.path.join('share',package_name,'rviz'),glob('rviz/*.rviz')),
    ],
    install_requires=['setuptools'], zip_safe=True,
    entry_points={'console_scripts':[
        'slam_toolbox_manager = pharmabot_phase3_v3.slam_toolbox_manager:main',
        'trained_agent_v3     = pharmabot_phase3_v3.trained_agent_v3:main',
    ]},
)
